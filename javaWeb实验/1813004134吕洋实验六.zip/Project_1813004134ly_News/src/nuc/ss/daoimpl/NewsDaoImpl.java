package nuc.ss.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import nuc.ss.dao.NewsDao;
import nuc.ss.entity.News;
import nuc.ss.util.DBUtil;

public class NewsDaoImpl implements NewsDao {

	@Override
	public int insertOne(News news) {
		String sql = "insert into t_news values(default,?,?,?,?,?)";
		Object[] objs = {news.getTitle(), news.getAuthor(), news.getContent(), news.getEnterdate(), news.getHot()};
		int n = DBUtil.excuteDML(sql, objs);
		return n;
	}

	@Override
	public List<News> selectAll() {
		Connection conn = DBUtil.getConnection();
		String sql = "select * from t_news";
		PreparedStatement ps = DBUtil.getPreparedStatement(conn, sql);
		ResultSet rs = null;
		List<News> list = new ArrayList<News>();
		try {
			rs = ps.executeQuery();
			while(rs.next()) {
				News news = new News(rs.getInt("id"), rs.getString("title"),
						rs.getString("author"), rs.getString("content"),
						rs.getDate("enterdate"), rs.getInt("hot"));
				list.add(news);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(rs, ps, conn);
		}

		return list;
	}

	@Override
	public int deleteOne(int id) {
		String sql = "delete from t_news where id=?";
		Object[] objs = {id};
		int n = DBUtil.excuteDML(sql, objs);
		return n;
	}

	@Override
	public News selectOne(int id) {
		Connection conn = DBUtil.getConnection();
		String sql = "select * from t_news where id=?";
		PreparedStatement ps = DBUtil.getPreparedStatement(conn, sql);
		try {
			ps.setInt(1, id);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		News news = null;
		try {
			rs = ps.executeQuery();
			if(rs.next()) {
				news = new News(rs.getInt("id"), rs.getString("title"),
						rs.getString("author"), rs.getString("content"),
						rs.getDate("enterdate"), rs.getInt("hot"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(rs, ps, conn);
		}
		return news;		
	}

	@Override
	public int updateOne(News news) {
		String sql = "update t_news set title=?,author=?,content=?,enterdate=?,hot=? where id=?";
		Object[] objs = {news.getTitle(), news.getAuthor(), news.getContent(),
				         news.getEnterdate(), news.getHot(), news.getId()};
		int n = DBUtil.excuteDML(sql, objs);
		return n;
	}
	
	@Override
	public List<News> selectSome(News news) {
		Connection conn = DBUtil.getConnection();
		String sql = "select * from t_news where title like ? and author like ? and content like ?";
		PreparedStatement ps = DBUtil.getPreparedStatement(conn, sql);
		Object[] objs = {news.getTitle(), news.getAuthor(), news.getContent()};
		List<News> list = new ArrayList<News>();
		try {
			for (int i = 0; i < objs.length; i++) {
				ps.setObject(i+1, "%"+objs[i]+"%");
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;

		try {
			rs = ps.executeQuery();
			while(rs.next()) {
				news = new News(rs.getInt("id"), rs.getString("title"),
						rs.getString("author"), rs.getString("content"),
						rs.getDate("enterdate"), rs.getInt("hot"));
			list.add(news);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(rs, ps, conn);
		}
		return list;		
	}

}
