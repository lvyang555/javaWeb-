package nuc.ss.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import nuc.ss.entity.News;
import nuc.ss.service.NewsService;
import nuc.ss.serviceimpl.NewsServiceImpl;

public class QueryNewsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	// 1銆佽В鍐崇紪鐮侀棶棰�
    	req.setCharacterEncoding("utf-8");
    	resp.setCharacterEncoding("utf-8");
    	resp.setContentType("text/html;charset=utf-8");
    	
    	//2銆佹帴鍙楀墠鍙版暟鎹�
    	int id = Integer.parseInt(req.getParameter("id"));
    	int flag = Integer.parseInt(req.getParameter("flag"));
    	
    	// 3銆佽皟鐢╯ervice灞傦紝鏌ヨ鎸囧畾id鐨勬柊闂讳俊鎭�
		NewsService ns = new NewsServiceImpl();
		
		News news = ns.queryOneNews(id);
		
		// 4銆佸鐞嗙粨鏋�
		if(news != null) {
			req.setAttribute("news", news);
			if(flag == 1) {
				req.getRequestDispatcher("updateNews.jsp").forward(req, resp);

			}else {
				req.getRequestDispatcher("displayNews.jsp").forward(req, resp);	
				news.setHot(news.getHot()+1);
				ns.updateNews(news);
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
	}

}
