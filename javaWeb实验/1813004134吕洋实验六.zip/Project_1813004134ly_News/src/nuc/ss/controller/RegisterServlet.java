package nuc.ss.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import nuc.ss.entity.User;
import nuc.ss.service.UserService;
import nuc.ss.serviceimpl.UserServiceImpl;

public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//设置编码格式
		req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		//获取前台数据
		String id = req.getParameter("uid");
		String name = req.getParameter("uname");
		String password = req.getParameter("upassword");
		String sex = req.getParameter("usex");
		String email = req.getParameter("uemail");
		java.util.Date regdate = new java.util.Date();
		
		User user = new User(id,name,password,sex,email,regdate);
		
		//调用service层，进行注册操作
		UserService us = new UserServiceImpl();

		int n = us.register(user);
		
		if(n > 0){
			//注册成功
			req.getSession().setAttribute("user", user);
			resp.sendRedirect("reg_success.jsp");			
		}else{
			String error = "注册失败！";
			if(n==-1){
				error = "您填写的登录ID已经存在！";	
			}
			req.getSession().setAttribute("error", error);
			resp.sendRedirect("reg_failure.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest req, HttpServletResponse resp)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
	}

}
