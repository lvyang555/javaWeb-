package nuc.ss.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import nuc.ss.entity.News;
import nuc.ss.service.NewsService;
import nuc.ss.serviceimpl.NewsServiceImpl;

/**
 * Servlet implementation class QueryServlet
 */
public class QueryServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
    	response.setCharacterEncoding("utf-8");
    	response.setContentType("text/html;charset=utf-8");
    	
    

    
    	String title =request.getParameter("title");
    	String author =request.getParameter("author");
    	String content=request.getParameter("content");
    	News news=new News(title, author, content);
    	
    	
		NewsService ns = new NewsServiceImpl();
		List<News> list =ns.querySomeNews(news);
		request.setAttribute("list", list);
		request.getRequestDispatcher("querySomeNews.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
