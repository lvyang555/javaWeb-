package nuc.ss.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import nuc.ss.entity.User;
import nuc.ss.service.UserService;
import nuc.ss.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		

		String uid = request.getParameter("uid");
		String upassword = request.getParameter("upassword");


		UserService us = new UserServiceImpl();
		User user = us.login(uid, upassword);


		if(user != null) {

			request.getSession().setAttribute("user", user);
			response.sendRedirect("queryAllNews");
		}else {
			request.getRequestDispatcher("login_failure.jsp").forward(request, response);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
