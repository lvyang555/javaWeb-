package nuc.ss.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import nuc.ss.entity.News;
import nuc.ss.service.NewsService;
import nuc.ss.serviceimpl.NewsServiceImpl;

public class AddNewsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    	req.setCharacterEncoding("utf-8");
    	resp.setCharacterEncoding("utf-8");
    	resp.setContentType("text/html;charset=utf-8");
    	

    	String title = req.getParameter("title");
    	String author = req.getParameter("author");
    	String content = req.getParameter("content");
    	String date_str = req.getParameter("enterdate");
    	String hot_str = req.getParameter("hot");
    	// String-->Util.Date
    	DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
    	Date date;
    	int hot;
    	News news = null;
		try {
			date = df.parse(date_str);
			hot = Integer.parseInt(hot_str);			
	    	news = new News(0, title, author, content, date, hot);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		NewsService ns = new NewsServiceImpl();
		
		int n = ns.addNews(news);

    	if(n >0) {

    		resp.sendRedirect("queryAllNews"); 
    	}else {

    		req.getRequestDispatcher("addNews.jsp").forward(req, resp);
    		
    	}


	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
	}

}
