package nuc.ss.service;

import nuc.ss.entity.User;

public interface UserService {

	int register(User user);

	User login(String uid, String pwd);

}
