package nuc.ss.service;

import java.util.List;

import nuc.ss.entity.News;

public interface NewsService {

	int addNews(News news);

	List<News> queryAllNews();

	int removeNews(int id);

	News queryOneNews(int id);

	int updateNews(News news);
	
	List<News> querySomeNews(News news);

}
