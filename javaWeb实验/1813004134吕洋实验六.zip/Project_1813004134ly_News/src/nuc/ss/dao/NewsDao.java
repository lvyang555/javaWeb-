package nuc.ss.dao;

import java.util.List;

import nuc.ss.entity.News;

public interface NewsDao {

	int insertOne(News news);

	List<News> selectAll();

	int deleteOne(int id);

	News selectOne(int id);

	int updateOne(News news);
	
	List<News> selectSome(News news);

}
