package nuc.ss.serviceimpl;

import nuc.ss.dao.UserDao;
import nuc.ss.daoimpl.UserDaoImpl;
import nuc.ss.entity.User;
import nuc.ss.service.UserService;

public class UserServiceImpl implements UserService{
	private UserDao ud = new UserDaoImpl();
	
	@Override
	public int register(User user) {
		if(ud.findOne(user.getUid())){
			return -1;
		}
		return ud.insertOne(user);
	}
/*	public int register(User user) {

		return ud.insertOne(user);
	}*/

	@Override
	public User login(String uid, String pwd) {
		
		return ud.findOne(uid, pwd);
	}

}
