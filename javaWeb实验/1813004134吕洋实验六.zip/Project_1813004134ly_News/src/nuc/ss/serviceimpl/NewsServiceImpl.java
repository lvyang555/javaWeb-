package nuc.ss.serviceimpl;

import java.util.List;

import nuc.ss.dao.NewsDao;
import nuc.ss.daoimpl.NewsDaoImpl;
import nuc.ss.entity.News;
import nuc.ss.service.NewsService;

public class NewsServiceImpl implements NewsService {
	private NewsDao nd = new NewsDaoImpl();
	@Override
	public int addNews(News news) {

		return nd.insertOne(news);
	}
	@Override
	public List<News> queryAllNews() {

		return nd.selectAll();
	}
	@Override
	public int removeNews(int id) {
		
		return nd.deleteOne(id);
	}
	@Override
	public News queryOneNews(int id) {
		
		return nd.selectOne(id);
	}
	@Override
	public int updateNews(News news) {
		
		return nd.updateOne(news);
	}
	@Override
	public List<News> querySomeNews(News news) {
		
		return nd.selectSome(news);
	}


}
