package lvyang_dao;

import java.util.List;

import lvyang_entity.userData;

public interface userDataDao {
	int insertOne(userData data);

	List<userData> selectAll();

	int deleteOne(int id);

	List<userData> select(String title,String realname);

	int updateOne(userData data);

}
