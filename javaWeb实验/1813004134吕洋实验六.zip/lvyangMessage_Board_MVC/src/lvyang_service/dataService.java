package lvyang_service;

import java.util.List;

import lvyang_entity.userData;

public interface dataService {
	
	int addData(userData data);
	
	List<userData> queryALLData();
	

	int removeUserData(int id);

	List<userData> queryUserData(String title,String realname);

	int updateData(userData data);

}
