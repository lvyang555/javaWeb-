package lvyang_service;

import lvyang_entity.User;

public interface UserService {
	int register(User user);

	User login(String name, String pwd);
}
