package lvyang_controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import lvyang_entity.User;
import lvyang_service.UserService;
import lvyang_serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserService us=new UserServiceImpl();
		request.setCharacterEncoding("utf-8");
		String name=request.getParameter("uname");
		String pwd=request.getParameter("upwd");
		HttpSession session = request.getSession();
		User user =us.login(name, pwd);
		if(user!=null){//��¼��֤
			session.setAttribute("name",name);
			session.setAttribute("pwd",pwd );
			  
			  request.getRequestDispatcher("lvyang_login_success.jsp?uname="+name).forward(request, response);
			  
				
			}else{              //��¼ʧ�ܣ���ת��ʧ��ҳ
				request.getRequestDispatcher("lvyang_login_failure.jsp").forward(request, response);
			   }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
