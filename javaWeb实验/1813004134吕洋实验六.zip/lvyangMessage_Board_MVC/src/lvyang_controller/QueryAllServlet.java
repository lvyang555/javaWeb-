package lvyang_controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import lvyang_entity.userData;
import lvyang_service.dataService;
import lvyang_serviceimpl.dataServiceImpl;

/**
 * Servlet implementation class QueryAllServlet
 */
public class QueryAllServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		dataService ds = new dataServiceImpl();
		String title = new String(request.getParameter("title").getBytes("iso-8859-1"), "utf-8");
		String realname = new String(request.getParameter("realname").getBytes("iso-8859-1"), "utf-8");
		List<userData> ud = ds.queryUserData(title, realname);
		HttpSession session = request.getSession();
		response.setContentType("text/html;cgarset=UTF-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out=response.getWriter();
		out.print("<h1>���԰�</h1>");
		out.print("<hr>	�����б� <br/><hr />");
		int i=1;
		for (userData us : ud) {
			out.print("�����ˣ�");
			out.print("<font color=\"blue\"> "+ us.getRealname()+" </font>");
			out.print("<br/>");
			out.print("ʱ��"+us.getTime());
			out.print("<br/>");
			out.print("����:"+us.getTitle());
			out.print("<br/>");
			out.print("����:"+us.getContent());
			out.print("<br/>");
			if (us.getName().equals((String) session.getAttribute("name"))) {
				
				
				out.print("<a href=DeleteMessageServlet?id="+us.getId()+">ɾ��&nbsp;</a>");
				out.print("<a href=lvyang_modify.jsp?id="+us.getId()+">�޸�&nbsp;</a>");
//				out.print("<input type= button value= ɾ��  "+"onclick= \" window.location.href='DeleteMessageServlet?id="+us.getId()+"\"'>");
//				out.print("<input type= button  value= �޸� " +
//						"onclick=\"window.location.href=lvyang_modify.jsp?id=\""+us.getId() +">");
				
			}
			out.print("<hr>");	
		}
		out.print("<a href=lvyang_login_success.jsp>������ҳ��&nbsp;</a>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
