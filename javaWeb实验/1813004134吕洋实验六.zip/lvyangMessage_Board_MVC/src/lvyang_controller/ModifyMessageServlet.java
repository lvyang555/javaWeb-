package lvyang_controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import lvyang_entity.userData;
import lvyang_service.dataService;
import lvyang_serviceimpl.dataServiceImpl;

/**
 * Servlet implementation class ModifyMessageServlet
 */
public class ModifyMessageServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		dataService ds =new dataServiceImpl();
		HttpSession session = request.getSession();
		int id = Integer.valueOf(request.getParameter("id"));
		String title = new String(request.getParameter("title").getBytes("iso-8859-1"), "utf-8");
		String name = new String(((String) session.getAttribute("name")).getBytes("iso-8859-1"), "utf-8");
		String content = new String(request.getParameter("content").getBytes("iso-8859-1"), "utf-8");
		response.setContentType("text/html;cgarset=UTF-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out=response.getWriter();
		userData ud =new userData(id,name,content,title);
		int count=ds.updateData(ud);
		if (count == 1) {
			out.print("<script language='javascript'>alert('�޸ĳɹ���');</script>");

		}else {
			out.print("<script language='javascript'>alert('�޸�ʧ�ܣ�');</script>");
		}
		request.getRequestDispatcher("lvyang_login_success.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
