package lvyang_controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lvyang_service.dataService;
import lvyang_serviceimpl.dataServiceImpl;

/**
 * Servlet implementation class DeleteMessageServlet
 */
public class DeleteMessageServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		dataService ds=new dataServiceImpl();
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;cgarset=UTF-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out=response.getWriter();
		int id = Integer.valueOf(request.getParameter("id"));
		int count=ds.removeUserData(id);
		if (count == 1) {
			out.print("<script language='javascript'>alert('ɾ���ɹ���');</script>");
		}else {
			out.print("<script language='javascript'>alert('ɾ��ʧ�ܣ�');</script>");
		}
		request.getRequestDispatcher("lvyang_login_success.jsp").forward(request, response);;
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
