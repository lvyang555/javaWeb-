package lvyang_controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lvyang_entity.User;
import lvyang_service.UserService;
import lvyang_serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class AddUserServlet
 */
public class AddUserServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserService us=new UserServiceImpl();
		String name=new String(request.getParameter("uname").getBytes("iso-8859-1"),"utf-8");
		String pwd=new String(request.getParameter("upwd").getBytes("iso-8859-1"),"utf-8");
		String realname=new String(request.getParameter("realname").getBytes("iso-8859-1"),"utf-8");
		User user=new User(name,pwd,realname);
		if(us.register(user)==1){
			response.sendRedirect("lvyang_login.jsp");
		}else{
			response.setContentType("text/html;cgarset=UTF-8");
			response.setCharacterEncoding("utf-8");
			PrintWriter out=response.getWriter();
			out.print("�û����ѱ�ע�ᣬע��ʧ��");
			out.print("<br/>");
			out.print("3����Զ���ת��ע��ҳ��");
			response.setHeader("refresh", "3;lvyang_register.jsp");
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
