package lvyang_controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lvyang_entity.userData;
import lvyang_service.dataService;
import lvyang_serviceimpl.dataServiceImpl;

/**
 * Servlet implementation class AddMessageServlet
 */
public class AddMessageServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		dataService ds=new dataServiceImpl();
		String title=new String(request.getParameter("title").getBytes("iso-8859-1"),"utf-8");
		String name=new String(request.getParameter("name").getBytes("iso-8859-1"),"utf-8");
		String realname=new String(request.getParameter("realname").getBytes("iso-8859-1"),"utf-8");
		String content=new String(request.getParameter("content").getBytes("iso-8859-1"),"utf-8");
		Date date=new Date();
		SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time=df.format(date);
		userData userData=new userData(realname,name, content, time, title);
		int count=-1;
		count=ds.addData(userData);
		response.setContentType("text/html;cgarset=UTF-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out=response.getWriter();
		if(count==1){
			
			out.print("<script language='javascript'>alert('�����ɹ���');</script>");
			request.getRequestDispatcher("lvyang_login_success.jsp?uname="+name).forward(request, response);
		}else {
			out.print("<script language='javascript'>alert('����ʧ�ܣ�');</script>");
			response.sendRedirect("lvyang_addMessage.jsp");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
