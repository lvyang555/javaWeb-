package lvyang_serviceimpl;

import java.util.List;

import lvyang_dao.userDataDao;
import lvyang_daoimpl.userDataDaoImpl;
import lvyang_entity.userData;
import lvyang_service.dataService;

public class dataServiceImpl implements dataService{
	
	private userDataDao udd=new userDataDaoImpl();
	@Override
	public int addData(userData data) {
		return udd.insertOne(data);
	}

	@Override
	public List<userData> queryALLData() {
		return udd.selectAll();
	}

	@Override
	public int removeUserData(int id) {
		return udd.deleteOne(id);
	}

	@Override
	public List<userData> queryUserData(String title,String realname) {
		return udd.select(title, realname);
	}

	@Override
	public int updateData(userData data) {
		
		return udd.updateOne(data);
	}

}
