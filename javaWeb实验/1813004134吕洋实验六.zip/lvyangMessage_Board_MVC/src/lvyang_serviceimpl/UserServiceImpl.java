package lvyang_serviceimpl;

import lvyang_dao.UserDao;
import lvyang_daoimpl.UserDaoimpl;
import lvyang_entity.User;
import lvyang_service.UserService;


public class UserServiceImpl implements UserService{
	private UserDao ud = new UserDaoimpl();
	@Override
	public int register(User user) {
		if(ud.findOne(user.getName())) {
			return -1;
		}
		return ud.insertOne(user);
	}

	@Override
	public User login(String name, String pwd) {
		return ud.findOne(name, pwd) ;
	}
	

}
