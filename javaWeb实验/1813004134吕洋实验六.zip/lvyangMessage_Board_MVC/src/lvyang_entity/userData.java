package lvyang_entity;

public class userData {
	
	private int id;
	private String realname;
	private String name;
	private String content;
	private String time;
	private String title;
	
	
	public userData() {
	}
	
	
	public userData(int id, String realname, String name, String content, String time, String title) {
		super();
		this.id = id;
		this.realname = realname;
		this.name = name;
		this.content = content;
		this.time = time;
		this.title = title;
	}
	
	



	public userData(int id, String name, String content, String title) {
		super();
		this.id = id;
		this.name = name;
		this.content = content;
		this.title = title;
	}


	public userData(String realname, String name, String content, String time, String title) {
		super();
		this.realname = realname;
		this.name = name;
		this.content = content;
		this.time = time;
		this.title = title;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRealname() {
		return realname;
	}
	public void setRealname(String realname) {
		this.realname = realname;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	
	

}
