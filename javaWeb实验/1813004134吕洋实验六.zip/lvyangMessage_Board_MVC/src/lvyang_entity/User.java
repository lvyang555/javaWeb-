package lvyang_entity;

public class User {
	
	private String name;
	private String pwd;
	private String realname;
	

	public User() {
		
	}
	
	
	
	public User(String name, String pwd, String realname) {
		super();
		this.name = name;
		this.pwd = pwd;
		this.realname = realname;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getRealname() {
		return realname;
	}
	public void setRealname(String realname) {
		this.realname = realname;
	}
	
	
	

}
