package lvyang_daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import lvyang_dao.UserDao;
import lvyang_entity.User;
import lvyang_util.DBUtil;

public class UserDaoimpl implements UserDao{

	@Override
	public int insertOne(User user) {
		String sql ="insert into login values(?,?,?)";
		Object[] objs= { user.getName(),user.getPwd(),user.getRealname()};
		int n=DBUtil.excuteDML(sql, objs);
		return n;
	}

	@Override
	public User findOne(String name, String pwd) {
		
		Connection connection =DBUtil.getConnection();
		String sql ="select * from login where name=?and pwd=?";
		PreparedStatement pstmt =DBUtil.getPreparedStatement(connection, sql);
		ResultSet rs=null;
		User user=null;
		
		try {
			pstmt.setString(1, name);
			pstmt.setString(2, pwd);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				user = new User(rs.getString("name"),rs.getString("pwd"),rs.getString("realname"));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(rs, pstmt, connection);
		}
		
		return user;
		
	
	}

	@Override
	public boolean findOne(String name) {
		Connection connection =DBUtil.getConnection();
		String sql ="select * from login where name=?";
		PreparedStatement pstmt =DBUtil.getPreparedStatement(connection, sql);
		ResultSet rs=null;
		
		try {
			pstmt.setString(1, name);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(rs, pstmt, connection);
		}
		
		return false;
	}

}
