package lvyang_daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import lvyang_dao.userDataDao;
import lvyang_entity.userData;
import lvyang_util.DBUtil;

public class userDataDaoImpl implements userDataDao{

	@Override
	public int insertOne(userData data) {
		String sql ="insert into data(realname,name,content,time,title) values(?,?,?,?,?) ";
		Object[] objs= {data.getRealname(),data.getName(),data.getContent(),data.getTime(),data.getTitle() };
		int n=DBUtil.excuteDML(sql, objs);
		return n;
	}

	@Override
	public List<userData> selectAll() {
		Connection conn = DBUtil.getConnection();
		String sql = "select * from data";
		PreparedStatement pstmt = DBUtil.getPreparedStatement(conn, sql);
		ResultSet rs = null;
		List<userData> list = new ArrayList<>();
		try {
			rs = pstmt.executeQuery();
		
			SimpleDateFormat df = new SimpleDateFormat("yyyy��MM��dd��HHʱmm��ss��");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));

			while(rs.next()) {
				userData userdata= new userData(rs.getInt("id"),rs.getString("realname"),rs.getString("name"),rs.getString("content"),df.format(rs.getTimestamp("time")),rs.getString("title"));
				
				list.add(userdata);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(rs, pstmt, conn);
		}
		return list;
	}

	@Override
	public int deleteOne(int id) {
		String sql = "delete from data where id=?";
		Object[] objs = {id};
		int n = DBUtil.excuteDML(sql, objs);
		return n;
	}

	@Override
	public List<userData> select(String title, String realname) {
		Connection conn = DBUtil.getConnection();
		String sql = "select * from data where title=?and realname=?";
		PreparedStatement pstmt = DBUtil.getPreparedStatement(conn, sql);
		try {
			pstmt.setString(1, title);
			pstmt.setString(2, realname);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		ResultSet rs = null;
		List<userData> list = new ArrayList<>();
		
		try {
			rs = pstmt.executeQuery();
			SimpleDateFormat df = new SimpleDateFormat("yyyy��MM��dd��HHʱmm��ss��");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));
			while(rs.next()) {
				userData userdata= new userData(rs.getInt("id"),rs.getString("realname"),rs.getString("name"),rs.getString("content"),df.format(rs.getTimestamp("time")),rs.getString("title"));
				
				list.add(userdata);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(rs, pstmt, conn);
		}
		return list;
		

	}

	@Override
	public int updateOne(userData data) {
		String sql="update data set title=?,content=? where name=? and id =?";
		Object[] objs= {data.getTitle(),data.getContent(),data.getName(),data.getId()};
		int n = DBUtil.excuteDML(sql, objs);
		return n;
	}

}
